# ExchangeRate

> This is a Final project of CIT590 written by shunl & ruizi

## What is it?

This is a Currency exchange calculator.

## How to run my code

This is a Maven project, so please use Maven build in Eclipse.

Please use this configuration to run the application.
Where “Goals: clean javafx:run”

Please use this configuration to run the Unittest.
Where “Goals: test”.

## How to Use this Calculator
Here is the window of the calculator:


There are two menu buttons for two kinds of currencies, the one above is the type of currency you want to convert, the one below is for the target currency.

Also, we have an update button to get the latest rate for now.

Finally, we have a virtual keyboard and this calculator supports two ways of input, you can choose directly click the button on the screen, this is for those who do not have a keyboard of their devices holds this calculator. Also, you can just use the keyboard of your own computer for inputting.

In the keyboard, we have 10 integers from 0 to 10, a decimal point and a clear button ( clear the input value in one time).



Function display
Choose the currency type by the menu button
Type or click the button to input the value for the first currency 




## API

The API we used is https://www.exchangerate-api.com/.


